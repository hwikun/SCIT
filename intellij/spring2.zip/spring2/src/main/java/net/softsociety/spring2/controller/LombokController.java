package net.softsociety.spring2.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class LombokController {
	@GetMapping("lombok")
	public String lombok() {
		return "lombok";
	}
}
